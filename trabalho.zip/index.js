async function retrieveProducts() {
  let pagination = ""
  let category = ""
  const urlParams = new URLSearchParams(window.location.search)
  const query = urlParams.get('query')

  function Detalhes() {
    // Lógica para exibir os detalhes do produto
    console.log("Detalhes do produto");
    console.log("(data");

  }

  if (urlParams.get('current_page'))
    pagination = "8page=" + urlParams.get('current_page')

  const data = await fetch('https://diwserver.vps.webdock.cloud/products/category/Accessories-Eyewear?page_items=20${pagination}').then(res => res.json())

  const list = document.getElementById("products")
  list.innerHTML = ""

  res.products.forEach(product => list.appendChild(createCard(product.id, product.title, product.brandname, product.image)))
}

async function productCategories() {
  const categories = await fetch('').then(res => res.json())

  const div = document.getElementById("categories")

  categories.forEach(category => {
    const option = document.createElement("option")
    option.innerHTML = category
    option.value = category

    div.appendChild(option)
  })
}



function getProducts() {
  const div = document.getElementById("lista");

  fetch("https://diwserver.vps.webdock.cloud/products/category/Accessories%20-%20Eyewear?page_items=24")
    .then(response => response.json())
    .then(data => {

      let str = '';
      data.products.forEach(produto => {
        str += `<div class="col-md-4" >
          <div class="card mt-1">
              <img src="${produto.image}" class="card-img-top" alt="...">
              <div class="card-body d-flex flex-column my-4">
                  <h5 class="card-title text-primary">${produto.title}</h5>
                  <p class="card-text">Rating ${produto.rating.rate} (${produto.rating.count})</p>
                  <p class="card-text">Price U$ ${produto.price}</p>
                  <a href=Detalhes.html?id=${produto.id}" targent"_blank" class="btn btn-dark mb-2"> Mais detalhes</a>
                  <a href="detalhes.html" class="btn btn-danger">Comprar</a>
              </div>
          </div>
        </div>`;
      });

      div.innerHTML = str;
    });
}

function cardProducts(produto) {
  return `<div class="card d-flex mx-auto my-3 col-md-4" style="width: 20rem;">
      <img src="${produto.image}" class="card-img-top" alt=...">
      <div class="card-body d-flex flex-column justify-content-between">
      <h5 class="card-title text_wd"> ${produto.title}</h5>
      <p class="card-text">Rating ${produto.rating.rate} (${produto.rating.count})</p>
      <p class="card-tex">Price U$ ${produto.price}</p>
      <a href="detalhes.html?id=${produto.id}" targent"_blank" class="btn btn-dark mb-2"> Mais detalhes</a>
      </div>
      </div>`
}

getProducts()